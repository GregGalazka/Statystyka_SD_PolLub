# FRC Dataset — Coverage Summary

**Total unique materials:** 483  (463 fiber-bearing + 20 baseline controls)
**Distinct source DOIs:** 63
**Provenance:** 289 primary · 189 review-tabulated · 5 derived
**Target:** ≥150 unique materials — **exceeded by ~3.2×.**

## Counts by fiber family
| Fiber family | Materials |
|---|---:|
| Hybrid | 100 |
| Natural | 92 |
| Synthetic | 88 |
| Steel | 80 |
| Glass | 47 |
| Basalt | 39 |
| Carbon | 37 |
| **Total** | **483** |

## Counts by matrix type
| Matrix | Materials |
|---|---:|
| Conventional concrete | 153 |
| UHPC | 108 |
| Geopolymer | 56 |
| SCC | 45 |
| Mortar | 41 |
| HPC | 28 |
| ECC | 26 |
| Lightweight | 23 |
| Other | 3 |
| **Total** | **483** |

## Family × Matrix (see frc_coverage_family_by_matrix.csv for full grid)
- **Steel** concentrates in UHPC/SCC/HPC + geopolymer; almost no conventional-concrete steel rows (sampling skew toward high-performance mixes).
- **Hybrid** (100) is dominated by UHPC (84) — mostly steel-steel and steel-synthetic combinations.
- **Natural** (92) spans the widest matrix range incl. Lightweight & Mortar; strongest sustainability/durability notes.
- **Glass/Carbon/Basalt** sit mostly in conventional concrete + mortar.
- **Synthetic** carries the ECC/SHCC rows (PVA, PE) with tensile-strain data.

## Property-axis population (share of rows with a stated value)

**Well-populated (≥45%) — ready for scoring now:**
- fiber_length_mm — 72.3%
- fiber_diameter_mm — 60.5%
- aspect_ratio — 47.8%
- fiber_dosage_vol_pct — 81.4%
- w_b_ratio — 61.3%
- cement_content_kg_m3 — 48.7%
- compressive_strength_MPa — 78.1%
- splitting_tensile_strength_MPa — 46.0%
- flexural_strength_MPa — 52.6%
- test_age_days — 76.4%
- durability_notes — 57.6%
- sustainability_notes — 48.2%

**Moderately populated (20–45%):**
- fiber_dosage_kg_m3 — 27.3%
- elastic_modulus_GPa — 21.5%
- slump_mm — 29.8%

**Poorly populated (<20%) — priority gaps to fill before scoring:**
- toughness_index — 7.5%
- fracture_energy_N_m — 11.2%
- tensile_strain_capacity_pct — 7.9%
- density_kg_m3 — 11.6%
- cost_notes — 9.5%

## Read-out for the scoring system
- **Mechanical axis:** strong. Compressive (78%), flexural (53%), splitting tensile (46%) are the reliable scoring inputs. Elastic modulus (22%), toughness (8%), fracture energy (11%), and tensile-strain (8%) are thin — either down-weight them or run a targeted top-up harvest.
- **Cost axis:** weakest quantitative axis (cost_notes 10%, mostly qualitative). Likely needs an external cost/price reference join rather than literature scraping.
- **Sustainability axis:** notes present on 48% of rows (concentrated in natural-fiber and geopolymer families); mostly qualitative — would benefit from a standardized embodied-carbon lookup.
- **Durability axis:** notes on 58% of rows but free-text and heterogeneous — will need parsing into structured sub-metrics (freeze-thaw, chloride, shrinkage) before it can be scored.

## Known coverage gaps (from harvest tracks)
- No continuous textile-reinforced concrete (TRC) fabric rows; AR-glass vs E-glass often undistinguished.
- Carbon skews to one recycled-CF factorial study + short-cut PAN; no pitch-based fibers.
- No crimped-form steel; conventional-concrete steel under-represented.
- Natural: flax, oil-palm, and processed cellulose/wood-pulp are zero-coverage.
- SCC thin (mostly PP); metakaolin geopolymers under-represented (many SCC/geopolymer PDFs were paywalled/not in PMC).
