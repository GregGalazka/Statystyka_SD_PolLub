# FRC Materials Master Dataset — Data Dictionary

**File:** `frc_materials_master.csv`
**Rows:** 483 unique fiber-reinforced concrete (FRC) materials (463 fiber-bearing + 20 baseline/control mixes, flagged)
**Sources:** 63 distinct peer-reviewed DOIs (298 rows primary-experimental, 185 review-tabulated)
**Unit of a row:** one unique material = (fiber_type + fiber_form + matrix_type + fiber_dosage) as reported in one specific study.
**Provenance rule:** a cell is populated ONLY where the cited source states the value; blank = not reported in that source (never imputed).

## Columns

### Identity
| Column | Units | Description |
|---|---|---|
| material_id | — | Stable row ID, `FRC-0001` … `FRC-0483`. |
| material_name | — | Short human-readable label (fiber / dosage / matrix). |
| fiber_family | controlled | One of: Steel, Glass, Carbon, Basalt, Synthetic, Natural, Hybrid. (Mineral folds into Glass/Basalt.) |
| fiber_type | free text | Specific fiber, e.g. "hooked-end steel", "AR-glass", "PAN carbon", "polypropylene", "PVA", "sisal". For hybrids, both fibers are listed. |
| fiber_form | controlled-ish | Geometry: hooked-end, straight, crimped, corrugated, chopped-strand, monofilament, fibrillated, mesh, twisted, milled. |

### Fiber geometry & dosage
| Column | Units | Description |
|---|---|---|
| fiber_length_mm | mm | Fiber length. |
| fiber_diameter_mm | mm | Fiber diameter / equivalent diameter (µm converted to mm). |
| aspect_ratio | — | L/d. |
| fiber_dosage_vol_pct | vol % | Fiber content by volume. Primary dosage axis. |
| fiber_dosage_kg_m3 | kg/m³ | Fiber content by mass per m³ (filled where the source used mass dosage). |

### Matrix
| Column | Units | Description |
|---|---|---|
| matrix_type | controlled | Conventional concrete, Mortar, HPC, UHPC, SCC, ECC, Geopolymer, Lightweight, Other. |
| binder_notes | free text | Cement/SCM detail: OPC, fly ash, GGBS, metakaolin, silica fume, etc. |
| w_b_ratio | — | Water/binder ratio. |
| cement_content_kg_m3 | kg/m³ | Binder content. |

### Mechanical
| Column | Units | Description |
|---|---|---|
| compressive_strength_MPa | MPa | Compressive strength. |
| splitting_tensile_strength_MPa | MPa | Splitting (Brazilian) tensile strength. |
| flexural_strength_MPa | MPa | Flexural strength / modulus of rupture. |
| elastic_modulus_GPa | GPa | Static elastic modulus. |
| toughness_index | — | Toughness index or equivalent (dimensionless or short note). |
| fracture_energy_N_m | N/m | Fracture energy (Gf). |
| tensile_strain_capacity_pct | % | Direct-tensile strain capacity (chiefly ECC/SHCC). |
| slump_mm | mm | Workability (slump / flow). |
| density_kg_m3 | kg/m³ | Hardened density. |
| test_age_days | days | Age at which mechanical values were measured (typically 28). |

### Durability / cost / sustainability (free-text notes)
| Column | Description |
|---|---|
| durability_notes | Freeze-thaw, chloride/corrosion, chemical & thermal resistance, shrinkage, water absorption, service-life remarks. |
| cost_notes | Any reported cost, relative cost, availability or commercial-maturity remark. |
| sustainability_notes | Bio-based / recyclable / waste-derived content, embodied-carbon or LCA remarks. |

### Provenance & QC
| Column | Description |
|---|---|
| source_doi | DOI of the cited source (validated `10.xxxx/...` format; 100% populated). |
| source_title | Title of the source. |
| source_year | Publication year. |
| source_type | experimental \| review. |
| provenance_flag | primary (source's own experiment) \| review-tabulated (source compiled it from another study) \| derived. |
| qc_flag | Automated QC notes: blanked implausible values, unit-suspect flags, baseline/control markers. Blank = passed all checks. |

## Notes & conventions
- **Numeric cells** hold a single float where the source reported one value; where the source gave a combined/hybrid dosage (e.g. `1.0 + 0.5`) or a range, the original string is preserved verbatim.
- **Dedup:** 49 exact duplicates (identical fiber/form/matrix/dosage/strength/DOI) were removed from the 532 raw extractions.
- **QC corrections:** 3 physically-impossible tensile-strain values (>15%, mis-mapped) were blanked; low-flexural and low-modulus outliers were retained but flagged for source verification; ultra-low-strength lightweight/foamed natural-fiber mixes were retained as plausible.
- **Controls:** 20 zero-fiber baseline mixes are included for reference and marked `baseline/control (0 fiber)` in qc_flag — filter them out for FRC-only analysis (leaves 463 materials).
- **Scoring readiness:** all four intended axes (mechanical, cost, sustainability, durability) have columns. Mechanical and mix-design fields are well-populated; cost, toughness, fracture energy, and tensile-strain are sparse (see coverage summary) and are the priority gaps to fill before scoring.
